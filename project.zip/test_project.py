from project import message_beginning, final_message, guess_number

def test_message_beginning():
    assert message_beginning("Hello") == True
    assert message_beginning(2) == True
    assert message_beginning("This is x-o game") == True
def test_final_beginning():
    assert final_message("Game") == True
    assert final_message("ww") == True
    assert final_message(5) == False
def test_guess_number():
    assert guess_number("Hello") == False
    assert guess_number("Hello 0 1 2") == False
    assert guess_number(0) == True