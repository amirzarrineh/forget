import random
import cowsay
import pathlib
# main
def main():
    print("\n\n\n             MIND PY \n\n\n")
    try:
        selectGame = int(input("Hello, for x-o input 1 <-> for guess number input 2: "))
    except ValueError:
        print("Invalid input please try again")
        exit()
    if selectGame == 1:
        file = pathlib.Path("score.txt")
        if file.exists ():
            try:
                qu = input("\nfor clear last records enter clear or plress enter to continue: ")
            except:
                print("invalid input please try again")
                exit()
            if qu == "clear":
                with open("score.txt",'r+') as file:
                    file.truncate(0)
            else:
                pass
        f = open("score.txt" , "a+")
        print("\nWelcome To X-O Game Dear Player\n")
        game_name = input("Please enter Game name: ")
        message_beginning(game_name)
        board = [' '] * 9
        current_player = "X" if choose_player() == "X" else "O"
        while True:
            display_board(board)
            print('Player', current_player, 'turn. Choose a position (1-9):')
            try:
                position_old = int(input()) 
            except ValueError:
                print()
            if 1 <= position_old <= 9:
                position = position_old - 1

                if board[position] != ' ':
                    print('Invalid move! Try again.')
                    continue

                board[position] = current_player

                if check_win(board):
                    display_board(board)
                    print('Player', current_player, 'wins!')
                    f.write(f'{game_name} : {current_player} wins\n')
                    final_message("Game <3")
                    break
                elif ' ' not in board:
                    display_board(board)
                    print(cowsay.cow('Tie!'))
                    final_message("Game <3")
                    f.write(f'{game_name} : tie\n')
                    break

                if current_player == 'X':
                    current_player = 'O'
                else:
                    current_player = 'X'
            else:
                print("invalid input please try again")
    elif selectGame == 2:
        try:
            guess_rule = int(input("how many chances do you need for guess (min:2) (max:5) : "))
            if 2 <= guess_rule <= 5: 
                guess_number(guess_rule)
            else:
                print("Invalid input please try again")
        except ValueError:
            print("Invalid value please try again")
            exit()
    else:
        print("invalid input please try again!")
        exit()

#random choices
def choose_player():
    player_choose = input("\n\nWho Starts first Please select X or O ? R for random : ")
    if player_choose == "X" or player_choose == "x":
        return "X"
    elif player_choose == "O" or player_choose == "o":
        return "O"
    elif player_choose == "R" or player_choose == "r":
        words = ["X" , "Y"]
        randR = random.choices(words)
        if randR == ['X']:
            new_randR = "X"
            return new_randR
        elif randR == ['O']:
            new_randR = "O"
            return randR

    else:
        print("invalid input please try again!")
        exit()
    
# Create Game table
def display_board(board):
    print(board[0] + '|' + board[1] + '|' + board[2])
    print('-+-+-')
    print(board[3] + '|' + board[4] + '|' + board[5])
    print('-+-+-')
    print(board[6] + '|' + board[7] + '|' + board[8])

# check winner
def check_win(board):
    for i in range(0, 9, 3):
        if board[i] == board[i+1] == board[i+2] and board[i] != ' ':
            return True
    for i in range(3):
        if board[i] == board[i+3] == board[i+6] and board[i] != ' ':
            return True
    if board[0] == board[4] == board[8] and board[0] != ' ':
        return True
    if board[2] == board[4] == board[6] and board[2] != ' ':
        return True
    return False
 
def message_beginning(message):
    if message:
        print(f"\nThis Game Called \"{message}\"\n")
        return True
    else :
        return False

def final_message(final):
    if type(final) == int:
        return False
    if final:
        print(f"\n\nI hope you enjoyed the {final}\n\n")
        return True
    else :
        return False

#second game
def guess_number(chance):
    if type(chance) == int:
        x = random.randint(1 , 10)
        i = 0
        while i < chance:
            user_input = int(input("Please input a number : "))
            if user_input < x:
                print("input less than Number.")
                i += 1
                
            elif user_input > x:
                print("input more than Number.")
                i += 1
                
            else:
                print("You win the game .")
                return True
        print("Game Ended")
        return True
    elif type(chance) == str:
        
        return False
    
if __name__ == '__main__':
    main()