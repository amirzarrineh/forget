# MIND.PY
### Video Demo: https://youtu.be/yHdPN-sY3n0
## Description:
The final project is a mind.py game made using python and is playable in the terminal by running the project.py file. You have to choose between two games (X-O) or guess-number.

The program consists of a main function and 6 other subprograms/functions namely display_board, check_win, message_beginning, final_message and guess_number which are called from the main funtion.

When you choose 1, in (X-O) the program will create a txt file called score.txt after you finishe the game it save your record which shows the winner record, and if socre.txt exist in the folder the program will ask you to clear score list or not.

when you choose 2, in guess number the program ask you to enter how many guess do you need to guessing the number  (between 2 and 5).

### Project Requirements:
&#9745; Your project must be implemented in Python.

&#9745; Your project must have a main function and at least three other functions, each of which must be accompanied by tests that can be executed with pytest.

&#9745; Your main function must be in a file called project.py, which should be in the “root” (i.e., top-level folder) of your project.

&#9745; Your 3 required custom functions other than main must also be in project.py and defined at the same indentation level as main (i.e., not nested under any classes or functions).

&#9745; Your test functions must be in a file called test_project.py, which should also be in the “root” of your project. Be sure they have the same name as your custom functions, prepended with test_ (test_custom_function, for example, where custom_function is a function you’ve implemented in project.py).

&#9745; You are welcome to implement additional classes and functions as you see fit beyond the minimum requirement.

&#9745; Implementing your project should entail more time and effort than is required by each of the course’s problem sets.

&#9745; Any pip-installable libraries that your project requires must be listed, one per line, in a file called requirements.txt in the root of your project.